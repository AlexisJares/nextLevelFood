import MainHeader from "@/components/main-header/main-header";

export default function MealsLayout({children}){
    return <>
        {children}
    </>
}