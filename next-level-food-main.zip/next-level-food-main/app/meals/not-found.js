export default function NotFound(){
    return <main className="not-found">
        <h1>Not Found meal</h1>
        <p>Try later</p>
    </main>
}